HOW TO RUN
```
docker build -t my-nest-app .
docker run -p 8080:8080 my-nest-app
```