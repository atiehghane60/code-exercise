interface VinListTypes {
  data: Array<string>;
}
