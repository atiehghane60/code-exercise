interface PlacesTypes {
    name: string,
    value: string,
}