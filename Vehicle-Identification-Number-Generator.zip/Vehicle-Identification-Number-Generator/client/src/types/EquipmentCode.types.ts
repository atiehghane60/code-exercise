interface EquipmentCodeTypes {
    name: string,
    value: string,
}