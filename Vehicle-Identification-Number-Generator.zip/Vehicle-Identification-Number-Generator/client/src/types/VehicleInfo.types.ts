
interface VehicleInfoTypes {
  version: string;
  equipmentCode: string;
  yearOfIssue: string;
  placeOfProduction: string;
  serialNumber: string;
  vin: string;
  searchSerialNumber: string;
  vinList: Array<string>;
}
