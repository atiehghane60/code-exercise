interface AddVinRequest {
  vin: string;
}
interface SearchSerialNumberRequest {
  version: string;
  equipmentCode: string;
  yearOfIssue: string;
  serialNumber: string;
  placeOfProduction: string;
}
